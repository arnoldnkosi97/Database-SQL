use BrokenVilleFinalDataBase
GO

CREATE PROCEDURE sp_insertPersonAddressContacts

(@IdNumber varchar(13),@Passport varchar(13),@Name varchar(20),@Surname varchar(20),@Gender varchar(6),@Nationality varchar(20),@Suburb varchar(15),
@StreetName varchar(15),@StreetNumber varchar(10),@ZipCode varchar(5),@ComplexName varchar(10),@UnitNumber int,@Telephone char(10),@Email ntext,@image text)

AS
BEGIN
     INSERT INTO tblPeople
	 (personID,pasportNumber,personName,personSurname,personGender,countryOfOrigin)
	 VALUES
	 (@IdNumber,@Passport,@Name,@Surname,@Gender,@Nationality)

	 INSERT INTO [dbo].[tblAddresses]
	 (unitNumber,complexNAme,streetNumber,streetName,suburb,zipCode)
	 VALUES
	 (@UnitNumber,@ComplexName,@StreetNumber,@StreetName,@Suburb,@ZipCode)

	 INSERT INTO [dbo].[tblContacts]
	 (telephone,email)
	 VALUES
	 (@Telephone,@Email)

	  INSERT INTO [dbo].[tblMedia]
	 (mediaData)
	 VALUES
	 (@image)

END