
use [BrokenVilleFinalDatabase]

go
CREATE PROCEDURE sp_gettingNotFixed
AS
BEGIN
     SELECT*
	 FROM [tblComplaint]
	 WHERE complaintStatus = 'fixed'

END