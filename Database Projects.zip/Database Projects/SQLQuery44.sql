use BrokenVilleFinalDatabase
go
DROP PROCEDURE fixed