use BrokenVilleFinalDB
go

CREATE PROCEDURE sp_SelectPersonID
(@id char(13))
AS
BEGIN

SELECT*
FROM [dbo].[tblPeople] P
INNER JOIN [dbo].[tblPrivilegeLevels] PL
ON PL.privilegeID =P.privilegeID
WHERE personID =@id

END