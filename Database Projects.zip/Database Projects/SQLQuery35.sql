use BrokenVilleFinalDatabase

go
create table Client
(
	IdNumber int primary key,
	name varchar(20),
	surname varchar(20),
	age int,
	gender varchar(6)
)

go
create table ContactInfo
(
	IdNumber int unique references Client(IdNumber),
	cellphoneNumber int primary key,
emailAddress varchar(20),
telephone int

)


go
create table AddressTable
( 
IdNumber int unique references Client(IdNumber),

addressID int primary key identity(1,1,),
	country varchar(20),
	province varchar(20),
	cityTown varchar(20),
	suburb varchar(20),
	streetName varchar(20),
	streetNumber varchar(5),
	postalCode int
)



go
create table complaints 
(
complaintID int primary key identity(1,1),
complaintDescription varchar(20)
)

go
create table Clientcomplaint
(
IdNumber int unique references Client(IdNumber),
complaintID int unique references complaints(complaintID)
)

go
create table ClientProduct
(
IdNumber int unique references Client(IdNumber),
productkey int primary key identity(1,1)
productkey int primary key identity(1,1),
productType varchar(10)
)

go
create table licenseFees
(
licenseId int primary key identity(1,1),
productkey int unique references Product(productkey),
paymentType varchar(10),
paymentAmount int
)

go
create table paymentDetails
(
IdNumber int unique references Client(IdNumber),
licenseId int unique references licenseFees(licenseId),
paymentTime smallDateTime
)

go
Create TABLE Employee
(
IdNumber int unique references Client(IdNumber),
EmpId int Primary KEY IDENTITY(1,1),
WorkTime smallDateTime
)

go
CREATE Table Maintenance
(
EmpId int unique references Employee(EmpId),
MaintenanceType varchar(20),
Expenses int,
DateFixed smallDateTime
)




go
create table tblStationDistrebution
(
	psID int references tblPowerstations(stationID),
	pdID int references tblPowerDistrebution(distrebutionID)
)

go
create table tblPowerWaist
(
	waistID int primary key identity(1,1),
	stationID int references tblPowerstations(stationID),
	amountWaisted varchar(4)
)

go
Create Table tblServiceProvider(
	serviceProviderID int Primary Key Identity(1,1),
	companyName varchar(20)
)

go
create table tblProperty
(
	propertyID int primary key identity(1,1),
	personID char(13) references tblPeople(personID),
	acres int,
	propertyName nvarchar,
)

go
create table tblMessages
(
	messageID int primary key identity(1,1),
	messageData text
)

go
create table tblSender
(
	personID char(13) references tblPeople(personID),
	messageID int references tblMessages(messageID)
)

go
create table tblReceiver
(
	personID char(13) references tblPeople(personID),
	messageID int references tblMessages(messageID)
)

go
create table tblEvents
(
	eventID int primary key identity(1,1),
	personID char(13) references tblPeople(personID),
	eventName varchar(20),
	eventDescription text,
	evetnDateTime smallDateTime
)

go
create table tblForcast
(
	forcastID int primary key identity(1,1),
	properyID int references tblProperty(propertyID),
	forcsatName varchar(20),
	forcastDescription text
)

go
create table tblSeasonType
(
	seasonID int primary key identity(1,1),
	seasonType varchar(20),
	seasonDiscription text
)


go
create table tblSeasonalForcast
(
	sfID int primary key identity(1,1),
	seasonID int references tblSeasonType(seasonID),
	forcastID int references tblForcast(forcastID),
	forcastArea varchar(30),
	sfDate date
)

go
create table tblDailyForcast
(
	dfID int primary key identity(1,1),
	forcastID int references tblForcast(forcastID),
	maxTemp int,
	minTemp int,
	forcastDescription text
)

go
create table tblProduce
(
	produceID int primary key identity(1,1),
	personID char(13) references tblPeople(personID),
	produceName varchar(15),
	producedAmount int
)


go
create table tblProduceTypes
(
	ptID int primary key identity(1,1),
	produceID int references tblProduce(produceID),
	ptName varchar(15),
	ptMaturityDates smallDateTime
)

go
create table tblProduceMarket
(
	pmID int primary key identity(1,1),
	produceID int references tblProduce(produceID),
	marketName varchar(20),
	pmDistrict varchar(20),
	pmCategory varchar(20),
	Unit varchar(20),
	price int,
	DateIssueFrom smalldatetime,
	DateIssueTo smalldatetime,
)

go
Create Table tblInvestment
(
	investmentID int Primary key identity(1,1),
	investmentAmount money
)

go
Create Table tblCompany
(
	companyID int Primary key identity(1,1),
	companyName varchar(30),
	companyLocation varchar(255) 
)
go
Create Table tblProduct
(
	productID int Primary key identity(1,1),
	productName varchar(30),
	productQuantity varchar(30),
	productPrice Money
)
go
Create Table tblExport
(
	exportID int Primary key identity(1,1),
	companyID int References tblCompany(companyID),
	productID int References tblProduct(productID),
	exportQuantity int,
	exportDestination varchar(30)
)
go
Create Table tblImport(
	importID int Primary key identity(1,1),
	companyID int References tblCompany(companyID),
	productID int References tblProduct(productID),
	importQuantity int,
	importOrigin varchar(30)
)
go 
Create Table tblPolutionType
(
	polutionTypeID int Primary key identity(1,1),
	polutionTypeName varchar(30),
	polutionTypeDescription varchar(300)
)
go
Create Table tblPolution
(
	polutionID int Primary key identity(1,1),
	polutionTypeID int References tblPolutionType(PolutionTypeID),
	polutionLocation varchar(30),
	polutionSeverity varchar(30),

)

go
create table tblMedia
(
	mediaID int primary key identity(1,1),
	mediaFileName varchar(20),
	mediaData text
)

go
create table tblAuditLog
(
	logID int primary key identity(1,1),
	dateCreated datetime,
	logDescription text,
	typeOfAction text
)

go
create table tblAdministrator 
(
	administratorID int primary key identity(1,1),
	personID char(13) references tblPeople(personID),
)

go
create table tblCriminalRecord 
(
	criminalRecordID int primary key identity(1,1),
	personID char(13) references tblPeople(personID),
	details text,
	dateOpened datetime
)

go
create table tblCriminalRecordDiscription
(
	criminalRecordDetailID int primary key identity(1,1),
	criminalRecordID int references tblCriminalRecord(criminalRecordID),
	criminalRecordDescription text
)

go
create table tblElection 
(
	electionID int primary key identity(1,1),
	startDateTime datetime,
	endDateTime	datetime,
	electionName varchar(20)
)

go
create table tblElectionCandidate 
(
	electionCandidateID int primary key identity(1,1),
	ElectionID		int   references tblElection(electionID),
	AdministratorID	int   references tblAdministrator(administratorID)
)

go
create table tblInfrastructureNotification 
(
	notificationID int primary key identity(1,1),
	personID char(13) references tblPeople(personID),
	notificationDescription text,
	notificationDateTime datetime,
	notificationType varchar(20),
	Severity int
)

go
create table tblCase
(
	caseID int primary key identity(1,1),
	created	datetime,
	caseNumber varchar(20),
	caseStatus varchar(20),
	details varchar(20)
)

go
create table tblSuspect 
(
	suspectID int primary key identity(1,1),
	caseID int references tblCase(caseID),
	PersonID char(13) references tblPeople(personID)
)

go
create table tblVote 
(
	voteID int primary key identity(1,1),
	voterID char(13) references tblPeople(personID),
	candidateID int references tblAdministrator(administratorID),
	createdDateTime	datetime
)

go
create table tblAccount 
(
	accountID int primary key identity(1,1),
	accountStatus varchar(20),
	occupants int,
	accountHolderID	char(13) references tblPeople(personID),
	dateCreated datetime
)

go
create table tblAccountPayment 
(
	paymentID int primary key identity(1,1),
	paymentDue money,
	accountID int references tblAccount(accountID),
	paid money,
	paymentMonth int,
	serviceType	int
)

go
create table tblCaseMedia 
(
	caseMediaID int primary key identity(1,1),
	caseID	int references tblCase(caseID),
	mediaID	int references tblMedia(mediaID)
)

go
create table tblPersonMedia 
(
	personMediaID int primary key identity(1,1),
	personID char(13) references tblPeople(personID),
	mediaID int references tblMedia(mediaID)
)

go
create table tblAddresses
(
	addressID int primary key identity(1,1),
	personID char(13) references tblPeople(personID),
	serviceProviderID int references tblServiceProvider(serviceProviderID),
	companyID int references tblCompany(companyID),
	regionID int unique references tblRegions(regionID),
	unitNumber int,
	complexName varchar(20),
	streetNumber int,
	streetName varchar(20),
	suburb varchar(20),
	zipCode char(4)
)

go
create table tblContacts
(
	contactID int primary key identity(1,1),
	personID char(13) references tblPeople(personID),
	serviceProviderID int references tblServiceProvider(serviceProviderID),
	companyID int references tblCompany(companyID),
    telephone char(10),
	email ntext
)

go
create table tblGPS 
(
	gpsID int primary key identity(1,1),
	addressID int references tblAddresses(addressID),
	notificationID int references tblInfrastructureNotification(notificationID),
	propertyID int references tblProperty(propertyID),
	eventID int references tblEvents(eventID),
	coordinates	varchar(20)
)

go
create table tblLogins
(
	personID char(13) unique references tblPeople(personID),
	companyID int references tblCompany(companyID),
	loginUsername nvarchar(20) primary key,
	loginPassword nvarchar(20)
)

go
Create Table tblComplaint(
	complaintID int Primary Key Identity(1,1),
	complaintLocation int references tblGPS(gpsID),
	complaintType varchar(20),
	complaintDescription text,
	complaintStatus varchar(10)
)

go
create table tblComplaintMedia
(
	complaintID int references tblComplaint(complaintID),
	mediaID int references tblMedia(mediaID)
)

go
Create Table tblPersonInvestment
(
	personInvestmentID int Primary key identity(1,1),
	loginUsername Nvarchar(20) unique References tblLogins(loginUsername),
	investmentID int References tblInvestment(InvestmentID)
)

go
Create Table tblPolutionNotice(
	polutionNoticeID int Primary key identity(1,1),
	polutionID int References tblPolution(PolutionID),
	loginUsername Nvarchar(20) unique References tblLogins(loginUsername)
)
go
Create Table tblComplaintPerson(
	ComplaintId int references tblComplaint(complaintID),
	PersonId char(13) references tblPeople(personID)
)

go
Create Table tblServiceProviderComplaint(
	ComplaintId int references tblComplaint(complaintID),
	serviceProviderID int references tblServiceProvider(serviceProviderID),
)


go
create table tblEmergency
(
	emergencyID int primary key identity(1,1),
	emergencyLocation int references tblGPS(gpsID),
	staffID int references tblStaff(staffID),
	emergencyDescription text,
	emergencyDateTime datetime
)

go
create table tblPeopleEmergency
(
	personID char(13) references tblPeople(personID),
	emergencyID int references tblEmergency(emergencyID)
)

go
create table tblPeopleRelocation 
(
	relocationID int primary key identity(1,1),
	personID char(13) references tblPeople(personID),
	MoveDateTime	datetime,
	MoveInID		int   references tblAddresses(addressID),
	MoveOutID		int   references tblAddresses(addressID)
)