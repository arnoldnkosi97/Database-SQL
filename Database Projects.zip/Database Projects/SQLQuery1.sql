use DBD321

go
create table Student
(
	IdNumber int primary key,
	name varchar(20),
	surname varchar(20),
	age int,
	gender varchar(6),
	yearOfStudy smalldatetime
)

go
create table Lecturer
(
IdNumber int primary key,
	name varchar(20),
	surname varchar(20),
	age int,
	gender varchar(6)
)


go
create table Hostel
( 
RoomNumber varchar(50) Primary Key,
IdNumber int unique references Student(IdNumber),
HostelName varchar(20),
Campus varchar(20),
RoomType varchar(20)
)



go
create table Course 
(
CourseID varchar(20) primary key,
CoursetDescription varchar(20),
CourseCredit int,
IdNumber int unique references Lecturer(IdNumber)
)



go
create table Class
(
IdNumber int unique references Lecturer(IdNumber),
ClassCode varchar(20) primary key,
ClassDescription varchar(20),
)


go
create table SubjectModule
(
SubjectModuleCode varchar(20) primary key,
SubjectDescription varchar(20),
SubjectModuleCredit int
)




go
CREATE Table SubjectClass
(
SubjectModuleCode varchar(20) unique references SubjectModule(SubjectModuleCode),
ClassCode varchar(20) unique references Class(ClassCode)
)

go
create table Assignment
(
AssignmentId varchar(8) primary key,
SubjectModuleCode varchar(20) unique references SubjectModule(SubjectModuleCode),
MarkWeight int,
AssignmentStatus varchar(8)
)

go
create table Project
(
ProjectId varchar(8) primary key,
SubjectModuleCode varchar(20) unique references SubjectModule(SubjectModuleCode),
MarkWeight int,
ProjectStatus varchar(8)
)

go
Create TABLE SessionTimeTable
(
IdNumber int unique references Student(IdNumber),
SessionType varchar(15),
SessionTime smallDateTime
)

go
CREATE Table Mentor
(
MentorId varchar(8) primary key,
IdNumber int unique references Student(IdNumber)
)

go
CREATE Table Mentee
(
MenteeId varchar(8) primary key,
IdNumber int unique references Student(IdNumber)
)



go
CREATE Table MentorMentee
(
MentorId varchar(8) unique references Mentor(MentorId),
MenteeId varchar(8) unique references Mentee(MenteeId)
)
