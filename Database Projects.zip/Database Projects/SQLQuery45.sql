

use SmartHomeSystem
go
CREATE PROCEDURE sp_DeletePerson
(@id varchar(10))
AS
BEGIN 
DELETE Person
WHERE [IdNumber] = @id

END