
use [BrokenVilleFinalDatabase]
go
CREATE PROCEDURE sp_InsertEmployee
(@JobTitle varchar(10),@Salary money,@Qualification varchar(10),@staffResponsibilities varchar(10),@shiftDescription varchar(10),@shiftTime varchar(10))
AS
BEGIN
     INSERT INTO tblStaff
	 (JobTitle,Salary,qualifications,staffRresponsibilities)
	 VALUES
	 (@JobTitle,@Salary,@Qualification,@staffResponsibilities)

	   INSERT INTO tblShifts
	 (shiftDescription,[shiftTimes])
	 VALUES
	 (@shiftDescription,@shiftTime)
	 
END

