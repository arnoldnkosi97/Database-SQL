
use BrokenVilleFinalDB
GO

CREATE PROCEDURE sp_DeletePerson
(@id char(13))
AS
BEGIN
     DELETE [tblPeople]
	 WHERE personID = @id
     
END

