
use [BrokenVilleFinalDatabase]
go
DROP PROCEDURE sp_InsertEmployee