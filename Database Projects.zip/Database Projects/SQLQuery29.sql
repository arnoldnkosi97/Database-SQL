use BrokenVilleFinalDB
go

CREATE PROCEDURE sp_SelectPeople

AS
BEGIN

SELECT*
FROM [dbo].[tblPeople] P
INNER JOIN [dbo].[tblPrivilegeLevels] PL
ON PL.privilegeID =P.privilegeID

END