use master

go
create database BrokenVilleFinalDatabase
on primary
(
	name = "PrimaryDataFile",
	filename = "D:\Database\PrimaryDataFile.mdf",
	size = 5mb,
	maxsize = unlimited,
	filegrowth = 10%
)

log on
(
	name = "LogDataFile",
	filename = "D:\Database\LogDataFile.ldf",
	size = 5mb,
	maxsize = unlimited,
	filegrowth = 10%
)